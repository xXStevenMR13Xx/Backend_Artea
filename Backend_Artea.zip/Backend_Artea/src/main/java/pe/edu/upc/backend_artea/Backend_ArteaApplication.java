package pe.edu.upc.backend_artea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Backend_ArteaApplication {

    public static void main(String[] args) {
        SpringApplication.run(Backend_ArteaApplication.class, args);
    }

}
