package pe.edu.upc.backend_artea.dtos;

import lombok.*;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class DificultadCreateUpdateDTO {
    private String tipo;
}
