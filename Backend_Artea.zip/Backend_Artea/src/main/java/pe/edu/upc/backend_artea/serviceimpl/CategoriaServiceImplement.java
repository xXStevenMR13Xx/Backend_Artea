package pe.edu.upc.backend_artea.serviceimpl;

import org.springframework.stereotype.Service;
import pe.edu.upc.backend_artea.services.CategoriaService;

@Service
public class CategoriaServiceImplement implements CategoriaService {
}
