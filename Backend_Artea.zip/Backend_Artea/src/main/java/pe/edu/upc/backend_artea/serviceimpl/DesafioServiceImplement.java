package pe.edu.upc.backend_artea.serviceimpl;

import org.springframework.stereotype.Service;
import pe.edu.upc.backend_artea.services.DesafioService;

@Service
public class DesafioServiceImplement implements DesafioService {
}
