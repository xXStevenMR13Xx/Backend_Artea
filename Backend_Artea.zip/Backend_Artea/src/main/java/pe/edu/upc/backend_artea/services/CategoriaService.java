package pe.edu.upc.backend_artea.services;

public interface CategoriaService {
}
