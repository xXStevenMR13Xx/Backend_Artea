package pe.edu.upc.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Backend_ArteaApplicationTests {

    @Test
    void contextLoads() {
    }

}
